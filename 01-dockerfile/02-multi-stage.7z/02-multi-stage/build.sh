#! /bin/sh
docker build -t nodetest --target=test .

## re-run tests even if cache exists
# docker build -t nodetest --target=test --no-cache .
###############################################################################

#! /bin/sh
MICROSCANNER="not-very-secret-token"

docker build -t auditnode --target=audit --build-arg MICROSCANNER_TOKEN=$MICROSCANNER .

## re-run tests even if cache exists
# docker build -t auditnode --target=audit --build-arg MICROSCANNER_TOKEN=$MICROSCANNER --no-cache .